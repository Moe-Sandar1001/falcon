<?php $__env->startSection('page_title','FALCON | Products'); ?>

<?php $__env->startSection('content'); ?>

    <div style="padding-top: 50px;"></div>
    <div class="container">

        <div class="row ">
            <div class="col-md-9 rightborder" >
                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo e(asset('/upload/product/'.$product_detail->photo)); ?>" width="300px" height="300px" alt="">
                    </div>
                    <div class="col-md-6">
                        <h3><?php echo e($product_detail->title); ?></h3>
                        <hr>
                        <p>
                            Category:<?php $__currentLoopData = $product_detail->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                (<?php echo e($item); ?>)
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </p>

                        <hr>
                        <p>
                            <?php echo $product_detail->detail; ?>

                        </p>
                    </div>
                </div>

                <!-- ---------------Start View Details Table------------- -->
                <div class="row">

                    <div style="padding-top: 50px;"></div>

                    <h3 style="padding-left: 30px;">Product Description</h3>

                    <div style="padding : 30px;">
                        <table class="table table-responsive table-hover">
                            <thead>
                            <tr>
                                <th colspan="2">TECHNICAL DATA</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>Model No.</td>
                                <td><?php echo e($product_detail->model_no); ?></td>
                            </tr>
                            <!--<tr>-->
                            <!--    <td>Part No.</td>-->
                            <!--    <td><?php echo e($product_detail->part_no); ?></td>-->
                            <!--</tr>-->
                            <!--<tr>-->
                            <!--    <td>Capacity</td>-->
                            <!--    <td><?php echo e($product_detail->capacity); ?></td>-->
                            <!--</tr>-->
                             <?php if($product_detail->part_no && $product_detail->capacity): ?>
                            <tr>
                                <td>Part No.</td>
                                <td><?php echo e($product_detail->part_no); ?></td>
                            </tr>
                            <tr>
                                <td>Capacity</td>
                                <td><?php echo e($product_detail->capacity); ?></td>
                            </tr>
                            <?php elseif($product_detail->part_no): ?>
                            <tr>
                                <td>Part No.</td>
                                <td><?php echo e($product_detail->part_no); ?></td>
                            </tr>
                            <?php elseif($product_detail->capacity): ?>
                            <tr>
                                <td>Capacity</td>
                                <td><?php echo e($product_detail->capacity); ?></td>
                            </tr>
                            <?php else: ?>
                                "";
                            <?php endif; ?>
                            <tr>
                                <td>Type of Extinguishant</td>
                                <td><?php echo e($product_detail->type_of_extinguishant); ?></td>
                            </tr>
                            <tr>
                                <td>Type</td>
                                <td><?php echo e($product_detail->type); ?></td>
                            </tr>
                            <tr>
                                <td>Pressurised Agent</td>
                                <td><?php echo e($product_detail->pressurised_agent); ?></td>
                            </tr>
                            <tr>
                                <td>Working Pressure</td>
                                <td><?php echo e($product_detail->working_pressure); ?></td>
                            </tr>
                            <tr>
                                <td>Test Pressure</td>
                                <td><?php echo e($product_detail->test_pressure); ?></td>
                            </tr>
                            <tr>
                                <td>Temperature Range</td>
                                <td><?php echo e($product_detail->temperature_range); ?></td>
                            </tr>
                            <tr>
                                <td>Discharge Time (approx.)</td>
                                <td><?php echo e($product_detail->discharge_time); ?></td>
                            </tr>
                            <tr>
                                <td>Overall Height</td>
                                <td><?php echo e($product_detail->overall_height); ?></td>
                            </tr>
                            <tr>
                                <td>Cylinder Diameter</td>
                                <td><?php echo e($product_detail->cylinder_diameter); ?></td>
                            </tr>
                            <tr>
                                <td>Approx. Full Weight</td>
                                <td><?php echo e($product_detail->full_weight); ?></td>
                            </tr>
                            <tr>
                                <td>Body Material</td>
                                <td><?php echo e($product_detail->body_material); ?></td>
                            </tr>
                            <tr>
                                <td>Finishing</td>
                                <td><?php echo e($product_detail->finishing); ?></td>
                            </tr>
                            <tr>
                                <td>Class of Fire</td>
                                <td><?php echo e($product_detail->class_of_fire); ?></td>
                            </tr>
                            <tr>
                                <td>Fire Rating</td>
                                <td><?php echo e($product_detail->fire_rating); ?></td>
                            </tr>
                            <tr>
                                <td>Manufactured & Approved</td>
                                <td><?php echo e($product_detail->manufactured_and_approved); ?></td>
                            </tr>
                            <tr>
                                <td>Throw Range Discharge</td>
                                <td><?php echo e($product_detail->throw_range_discharge); ?></td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                    <div>
                        <hr>
                    </div>
                </div>
















































































                <!--  ------------------End View Details Table------------------   -->

            </div>

            <div class="col-md-3">
                <div class="row" style="padding-left: 30px;">







                    <!-- searchForm -->




                    <h5 style="font-size: 20px;">Product Categories</h5><br>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/products'.'/'.$category->id)); ?>" style="color: #010101;display: block;border-top: 1px solid #ccc;padding-top: 10px;padding-bottom: 10px;">
                            <?php echo e($category->name); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <br>

                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aungko/falconmyanmar.com/resources/views/user/view_detail.blade.php ENDPATH**/ ?>