<?php $__env->startSection('page_title','FALCON | Products'); ?>

<?php $__env->startSection('content'); ?>

    <div style="padding-top: 50px;"></div>
    <div class="container">

        <div class="row ">
            <div class="col-md-9 rightborder" >
                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo e($product_detail['photo_url']); ?>" width="300px" height="300px" alt="">
                    </div>
                    <div class="col-md-6">
                        <h3><?php echo e($product_detail['title']); ?></h3>
                        <hr>
                        <p>
                            Category: <?php echo e($product_detail->category_id); ?>

                        </p>

                        <hr>
                        <p>
                            <?php echo $product_detail->detail; ?>

                        </p><br>
                        <a href="<?php echo e($product_detail->pdf_url); ?>" target="_blank" class="button_all btn-sm pull-right">Download PDF</a>
                    </div>
                </div>

                <!-- ---------------Start View Details Table------------- -->
                <div class="row">

                    <div style="padding-top: 50px;"></div>

                    <h3 style="padding-left: 30px;">Product Description</h3>

                    <div style="padding : 30px;">
                        <table class="table table-responsive table-hover">
                            <thead>
                            <tr>
                                <th colspan="2">TECHNICAL DATA</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php echo $product_detail->summertable; ?>

                            </tbody>
                        </table>
                    </div>
                    <div>
                        <hr>
                    </div>
                </div>
















































































                <!--  ------------------End View Details Table------------------   -->

            </div>

            <div class="col-md-3">
                <div class="row" style="padding-left: 30px;">







                    <!-- searchForm -->




                    <h5 style="font-size: 20px;">Product Categories</h5><br>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/products'.'/'.$category->id)); ?>" style="color: #010101;display: block;border-top: 1px solid #ccc;padding-top: 10px;padding-bottom: 10px;">
                            <?php echo e($category->name); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <br>

                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\falconmyanmar\resources\views/user/view_detail.blade.php ENDPATH**/ ?>