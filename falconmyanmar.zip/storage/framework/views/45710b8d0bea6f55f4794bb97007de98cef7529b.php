<?php $__env->startSection('page_title','FALCON | Projects'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Slider area -->
    <section class="slider_area row m0">
        <div class="slider_inner">
            <div data-thumb="<?php echo e(asset('images/slider-1.jpg')); ?>" data-src="<?php echo e(asset('images/slider-1.jpg')); ?>">
                <div class="camera_caption">
                    <div class="container">

                        <h3 class=" wow fadeInUp animated" data-wow-delay="0.5s">MRT Underground Stations</h3>

                    </div>
                </div>
            </div>
            <div data-thumb="<?php echo e(asset('images/slider-2.jpg')); ?>" data-src="<?php echo e(asset('images/slider-2.jpg')); ?>">
                <div class="camera_caption">
                    <div class="container">

                        <h3 class=" wow fadeInUp animated" data-wow-delay="0.5s">Theme Park Resort</h3>

                    </div>
                </div>
            </div>
            <div data-thumb="<?php echo e(asset('images/slider-1.jpg')); ?>" data-src="<?php echo e(asset('images/slider-1.jpg')); ?>">
                <div class="camera_caption">
                    <div class="container">

                        <h3 class=" wow fadeInUp animated" data-wow-delay="0.5s">Shopping Centre/Retail Shop</h3>

                    </div>
                </div>
            </div>
            <div data-thumb="<?php echo e(asset('images/slider-2.jpg')); ?>" data-src="<?php echo e(asset('images/slider-2.jpg')); ?>">
                <div class="camera_caption">
                    <div class="container">

                        <h3 class=" wow fadeInUp animated" data-wow-delay="0.5s">Airport</h3>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Slider area -->

    <!-- Our Theme Part Resort Area -->
    <section class="latest_blog_area">
        <div class="container">
            <div class="tittle wow fadeInUp">
                <h2>Theme Park Resort</h2>

            </div>
            <div class="row latest_blog">
                <center>
                    <?php $__currentLoopData = $projects_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-sm-6 blog_content">
                            <img src="<?php echo e($data->photo_url); ?>" alt="" class="img-fluid" style="width: 100%; height: 200px;">
                            <div style="padding-top: 10px; font-style: bold; text-align: center; "><?php echo e($data->name); ?></div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </center>
            </div>
        </div>
    </section>
    <!-- End Our Theme Part Resort Area -->


    <!-- Shopping Centre/Retail Shop Area -->
    <section class="latest_blog_area" style="background-color: #3a3b3d;">
        <div class="container">
            <div class="tittle wow fadeInUp">
                <h2 style="color: #fff">Shopping Centre/Retail Shop</h2>

            </div>
            <div class="row latest_blog">
                <center>
                    <?php $__currentLoopData = $project_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-sm-6 blog_content">
                            <img src="<?php echo e($data->photo_url); ?>" alt="" class="img-fluid" style="width: 100%; height: 150px;">
                            <div style="padding-top: 10px; font-style: bold; color: #fff; text-align: center; "><?php echo e($data->name); ?></div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </center>
            </div>
        </div>
    </section>
    <!-- End Our Theme Part Resort Area -->

    <!-- Our Theme Part Resort Area -->




















    <!-- End Our Theme Part Resort Area -->

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\falconmyanmar\resources\views/user/projects.blade.php ENDPATH**/ ?>