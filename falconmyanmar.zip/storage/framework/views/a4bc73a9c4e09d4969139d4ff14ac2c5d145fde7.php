
<?php /**PATH D:\xampp\htdocs\falconmyanmar\resources\views/auth/register.blade.php ENDPATH**/ ?>