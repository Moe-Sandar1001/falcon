<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
    <div class="container-fluid">
        <div class="navbar-wrapper">
            <a class="navbar-brand" href="#pablo"><?php echo $__env->yieldContent('nav_bar_text'); ?></a>
        </div>


    </div>
</nav>
<!-- End Navbar --><?php /**PATH D:\Xampp\htdocs\falconmyanmar\resources\views/admin/layouts/site_admin/site_admin_navbar.blade.php ENDPATH**/ ?>