<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('page_title'); ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('images/user_image/images/favicon.png')); ?>" type="image/x-icon" />
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(url('css/user_css/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Animate CSS -->
    <link href="<?php echo e(url('vendors/animate/animate.css')); ?>" rel="stylesheet">
    <!-- Icon CSS-->
    <link rel="stylesheet" href="<?php echo e(url('vendors/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- Camera Slider -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/camera-slider/camera.css')); ?>">
    <!-- Owlcarousel CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('vendors/owl_carousel/owl.carousel.css')); ?>" media="all">

    <!--Theme Styles CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/user_css/css/style.css')); ?>" media="all" />

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
   <script src="js/html5shiv.min.js"></script>-->
    <!-- <script src="js/respond.min.js"></script>
    <![endif]-->

    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>


<!-- Header_Area -->
<?php echo $__env->make('user.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Header_Area -->

<?php echo $__env->yieldContent('slider'); ?>

<?php echo $__env->yieldContent('content'); ?>


<!-- Footer Area -->
<?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Footer Area -->

<?php echo $__env->yieldContent('js'); ?>
<!-- jQuery JS -->
<script src="<?php echo e(url('js/user_js/js/jquery-1.12.0.min.js')); ?>"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(url('js/user_js/js/bootstrap.min.js')); ?>"></script>
<!-- Animate JS -->
<script src="<?php echo e(url('vendors/animate/wow.min.js')); ?>"></script>
<!-- Camera Slider -->
<script src="<?php echo e(url('vendors/camera-slider/jquery.easing.1.3.js')); ?>"></script>
<script src="<?php echo e(url('vendors/camera-slider/camera.min.js')); ?>"></script>
<!-- Isotope JS -->
<script src="<?php echo e(url('vendors/isotope/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(url('vendors/isotope/isotope.pkgd.min.js')); ?>"></script>
<!-- Progress JS -->
<script src="<?php echo e(url('vendors/Counter-Up/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(url('vendors/Counter-Up/waypoints.min.js')); ?>"></script>
<!-- Owlcarousel JS -->
<script src="<?php echo e(url('vendors/owl_carousel/owl.carousel.min.js')); ?>"></script>
<!-- Stellar JS -->
<script src="<?php echo e(url('vendors/stellar/jquery.stellar.js')); ?>"></script>
<!-- Theme JS -->
<script src="<?php echo e(url('js/user_js/js/theme.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/aungko/falconmyanmar.com/resources/views/user/layouts/master.blade.php ENDPATH**/ ?>