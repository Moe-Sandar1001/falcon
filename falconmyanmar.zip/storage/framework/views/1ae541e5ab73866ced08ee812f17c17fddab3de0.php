<?php $__env->startSection('page_title','FALCON | Products'); ?>

<?php $__env->startSection('content'); ?>
    
    <!-- Our Available Products Area -->
    <section class="our_team_area">
        <div class="container">
            <div class="tittle wow fadeInUp">
                <h2>Products</h2>
            </div>
            <div class="row team_row" style="padding-top: 50px;">
                 <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-sm-6 wow fadeInUp">
                   <div class="team_membar">
                        <img src="<?php echo e(asset('/upload/product/'.$search_data->photo)); ?>" alt="">
                        <div class="team_content" style="height: 120px;">
                            <ul>
                                <li><a href="<?php echo e(url('/view_detail'.'/'.$search_data['id'])); ?>"><i class="fa fa-plus" aria-hidden="true"></i></a></li>
                            </ul>
                        
                        <a href="<?php echo e(url('/view_detail'.'/'.$search_data['id'])); ?>" class="name"><?php echo e($search_data->title); ?></a>
                        
                        </div>
                   </div>
                </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
           

<!-- -----------------------next row----------------- -->


        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\falconmyanmar\resources\views/user/search_product.blade.php ENDPATH**/ ?>