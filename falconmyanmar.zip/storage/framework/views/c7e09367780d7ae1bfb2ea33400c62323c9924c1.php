<div id="fb-root"></div>
        <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.3&appId=375244603347949&autoLogAppEvents=1"></script>
<footer class="footer_area">
    <div class="container">
        <div class="footer_row row">
            <div class="col-md-4 col-sm-6 footer_about">
                <h2>Facebook</h2>
                 <div class="fb-page" data-href="https://www.facebook.com/falconengineeringcompany/" data-tabs="timeline" data-width="" data-height="165px" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/falconengineeringcompany/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/falconengineeringcompany/">Falcon Myanmar</a></blockquote>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 footer_about">
                <h2>ABOUT OUR COMPANY</h2>
                <img src="images/footer-logo.png" alt="">
                <p style="text-align:justify;margin-top:-30px;">Founded in the year 2015, Falcon Engineering Company is based in Yangon, Myanmar.It is an engineering and trading company, distributing fire fighting equipment and related products to the local market from CHINA, INDIA, and SINGAPORE.</p>
                <ul class="socail_icon">
                    <li><a href="https://www.facebook.com/falconengineeringcompany/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>

                    <li><a href="#"><i class="fa fa-twitter" aria-hidden="true" target="_blank"></i></a></li>
                    
                    <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true" target="_blank"></i></a></li>
                </ul>
            </div>
            <div class="col-md-4 col-sm-6 footer_about quick">
                <h2>Quick links</h2>
                <ul class="quick_link">
                <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-chevron-right"></i>HOME</a></li>
                    <li><a href="<?php echo e(url('/about')); ?>"><i class="fa fa-chevron-right"></i>ABOUT US</a></li>
                    <li><a href="#"><i class="fa fa-chevron-right"></i>PRODUCTS</a></li>
                    <li><a href="<?php echo e(url('/projects')); ?>"><i class="fa fa-chevron-right"></i>OUR PROJECTS</a></li>
                    <li><a href="<?php echo e(url('/contact')); ?>"><i class="fa fa-chevron-right"></i>CONTACT US</a></li>
                    <li><a href="#"><i class="fa fa-chevron-right"></i>BUILDING</a></li>
                </ul>
            </div>
            
            
            <div class="col-md-12">
                <div class="row footer_about1">
                
                <div class="col-md-4">
                     <span class="myy_address" style="margin-buttom:-100px;"><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i> ppa@falconmyanmar.com</a></span>
                </div>
                 <div class="col-md-4">
                     <span class="myy_address"><a href="#"><i class="fa fa-phone" aria-hidden="true"></i> +959 964911300</a></span>
                </div>
                 <div class="col-md-4">
                    <span class="myy_address"> <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> No.95, Insein Road, (Near Khawel Chan Bus Stop), Yangon, Myanmar.</a></span>
                </div>
               
            </div>
            </div>

        </div>
       
    </div>
    <div class="copyright_area">
        Copyright 2019 All rights reserved. Designed by <a href="https://greenhackersinstitute.com" target="_blank">Green Hackers.</a>
    </div>
</footer><?php /**PATH /home/aungko/falconmyanmar.com/resources/views/user/layouts/footer.blade.php ENDPATH**/ ?>