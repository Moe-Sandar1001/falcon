<?php $__env->startSection('page_title','Downloads'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Banner area -->
    <section class="banner_area" data-stellar-background-ratio="0.5">
        <h2>Downloads</h2>
        <ol class="breadcrumb">
            <li><a href="index.html">Home</a></li>
            <li><a href="#" class="active">Downloads</a></li>
        </ol>
    </section>
    <!-- End Banner area -->
    <br><br>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('images/cns-2.jpg')); ?>" alt="" class="img-responsive" width="100%">
                        </div>
                        <div class="col-md-8">
                            <h2>
                                Hellowen
                            </h2>
                            <p>
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo nesciunt aspernatur, obcaecati unde doloribus at aperiam mollitia aliquid natus dolores! Corrupti autem eum molestias numquam, quisquam libero sapiente soluta mollitia.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus inventore eius nisi porro fuga necessitatibus explicabo nemo nesciunt.
                            </p>
                            <a href="#" class="button_all">Downloads</a>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('images/cns-2.jpg')); ?>" alt="" class="img-responsive" width="100%">
                        </div>
                        <div class="col-md-8">
                            <h2>
                                Hellowen
                            </h2>
                            <p>
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo nesciunt aspernatur, obcaecati unde doloribus at aperiam mollitia aliquid natus dolores! Corrupti autem eum molestias numquam, quisquam libero sapiente soluta mollitia.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus inventore eius nisi porro fuga necessitatibus explicabo nemo nesciunt.
                            </p>
                            <a href="#" class="button_all">Downloads</a>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('images/cns-2.jpg')); ?>" alt="" class="img-responsive" width="100%">
                        </div>
                        <div class="col-md-8">
                            <h2>
                                Hellowen
                            </h2>
                            <p>
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo nesciunt aspernatur, obcaecati unde doloribus at aperiam mollitia aliquid natus dolores! Corrupti autem eum molestias numquam, quisquam libero sapiente soluta mollitia.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus inventore eius nisi porro fuga necessitatibus explicabo nemo nesciunt.
                            </p>
                            <a href="#" class="button_all">Downloads</a>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('images/cns-2.jpg')); ?>" alt="" class="img-responsive" width="100%">
                        </div>
                        <div class="col-md-8">
                            <h2>
                                Hellowen
                            </h2>
                            <p>
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo nesciunt aspernatur, obcaecati unde doloribus at aperiam mollitia aliquid natus dolores! Corrupti autem eum molestias numquam, quisquam libero sapiente soluta mollitia.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus inventore eius nisi porro fuga necessitatibus explicabo nemo nesciunt.
                            </p>
                            <a href="#" class="button_all">Downloads</a>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('images/cns-2.jpg')); ?>" alt="" class="img-responsive" width="100%">
                        </div>
                        <div class="col-md-8">
                            <h2>
                                Hellowen
                            </h2>
                            <p>
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo nesciunt aspernatur, obcaecati unde doloribus at aperiam mollitia aliquid natus dolores! Corrupti autem eum molestias numquam, quisquam libero sapiente soluta mollitia.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus inventore eius nisi porro fuga necessitatibus explicabo nemo nesciunt.
                            </p>
                            <a href="#" class="button_all">Downloads</a>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('images/cns-2.jpg')); ?>" alt="" class="img-responsive" width="100%">
                        </div>
                        <div class="col-md-8">
                            <h2>
                                Hellowen
                            </h2>
                            <p>
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo nesciunt aspernatur, obcaecati unde doloribus at aperiam mollitia aliquid natus dolores! Corrupti autem eum molestias numquam, quisquam libero sapiente soluta mollitia.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus inventore eius nisi porro fuga necessitatibus explicabo nemo nesciunt.
                            </p>
                            <a href="#" class="button_all">Downloads</a>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('images/cns-2.jpg')); ?>" alt="" class="img-responsive" width="100%">
                        </div>
                        <div class="col-md-8">
                            <h2>
                                Hellowen
                            </h2>
                            <p>
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo nesciunt aspernatur, obcaecati unde doloribus at aperiam mollitia aliquid natus dolores! Corrupti autem eum molestias numquam, quisquam libero sapiente soluta mollitia.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus inventore eius nisi porro fuga necessitatibus explicabo nemo nesciunt.
                            </p>
                            <a href="#" class="button_all">Downloads</a>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('images/cns-2.jpg')); ?>" alt="" class="img-responsive" width="100%">
                        </div>
                        <div class="col-md-8">
                            <h2>
                                Hellowen
                            </h2>
                            <p>
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo nesciunt aspernatur, obcaecati unde doloribus at aperiam mollitia aliquid natus dolores! Corrupti autem eum molestias numquam, quisquam libero sapiente soluta mollitia.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus inventore eius nisi porro fuga necessitatibus explicabo nemo nesciunt.
                            </p>
                            <a href="#" class="button_all">Downloads</a>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('images/cns-2.jpg')); ?>" alt="" class="img-responsive" width="100%">
                        </div>
                        <div class="col-md-8">
                            <h2>
                                Hellowen
                            </h2>
                            <p>
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo nesciunt aspernatur, obcaecati unde doloribus at aperiam mollitia aliquid natus dolores! Corrupti autem eum molestias numquam, quisquam libero sapiente soluta mollitia.
                                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus inventore eius nisi porro fuga necessitatibus explicabo nemo nesciunt.
                            </p>
                            <a href="#" class="button_all">Downloads</a>
                        </div>
                    </div>
                    <hr>
                    
                </div>
            </div>
        </div>
    </section>
    <br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\falconmyanmar\resources\views/user/downloads.blade.php ENDPATH**/ ?>