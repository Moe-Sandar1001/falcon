

<?php $__env->startSection('page_title','Downloads'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Banner area -->
    <section class="banner_area" data-stellar-background-ratio="0.5">
        <h2>Downloads</h2>
        <ol class="breadcrumb">
            <li><a href="index.html">Home</a></li>
            <li><a href="#" class="active">Downloads</a></li>
        </ol>
    </section>
    <!-- End Banner area -->
    <br><br>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php $__currentLoopData = $pdf_downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">

                        <div class="col-md-4">
                            <img src="<?php echo e($data['photo_url']); ?>" alt="" class="img-responsive" style="width:350px; height:200px;">
                        </div>
                        <div class="col-md-8">
                            <h2>
                            <?php echo e($data['name']); ?>

                            </h2><br>
                            <p>
                            <?php echo $data['description']; ?>

                            </p>
                            <a href="<?php echo e($data->pdf_url); ?>" target="_blank" class="button_all"> PDF Downloads</a>
                        </div>
                    </div>
                    <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($downloads->links()); ?>

                </div>
            </div>
        </div>
    </section>
    <br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aungko/falconmyanmar.com/resources/views/user/downloads.blade.php ENDPATH**/ ?>