<?php


namespace App\CustomClass;


class Path
{
    static public $domain_url= "http://localhost/falconmyanmar/public/";
}