<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slidephoto extends Model
{
    protected $fillable = [
        'id',
        'photo'
    ];
}
